#!/usr/bin/env bash
# ============================================================================
# Dotfiles Installation Script
# ============================================================================

set -e

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=============================================="
echo "       DOTFILES INSTALLATION SCRIPT        "
echo "=============================================="
echo ""
echo "Dotfiles directory: $DOTFILES_DIR"
echo ""

# ===== COLORS =====
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ===== FUNCTIONS =====
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# ===== CHECK REQUIREMENTS =====
print_info "Checking requirements..."

if [ ! -d "$HOME/.oh-my-zsh" ]; then
    print_warning "Oh My Zsh not found. Install zsh first."
fi

# ===== BACKUP EXISTING FILES =====
print_info "Backing up existing files..."

# Create backup directory
BACKUP_DIR="$HOME/.dotfiles_backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

# Backup existing files
[ -f "$HOME/.zshrc" ] && cp "$HOME/.zshrc" "$BACKUP_DIR/" && print_success "Backed up .zshrc"
[ -f "$HOME/.bashrc" ] && cp "$HOME/.bashrc" "$BACKUP_DIR/" && print_success "Backed up .bashrc"
[ -f "$HOME/.gitconfig" ] && cp "$HOME/.gitconfig" "$BACKUP_DIR/" && print_success "Backed up .gitconfig"
[ -f "$HOME/.config/fish/config.fish" ] && cp "$HOME/.config/fish/config.fish" "$BACKUP_DIR/" && print_success "Backed up fish config.fish"
[ -f "$HOME/.tmux.conf" ] && cp "$HOME/.tmux.conf" "$BACKUP_DIR/" && print_success "Backed up .tmux.conf"

# ===== INSTALL ZSH CONFIG =====
print_info "Installing Zsh configuration..."

# Link .zshrc
ln -sf "$DOTFILES_DIR/zsh/.zshrc" "$HOME/.zshrc"
print_success "Linked .zshrc"

# ===== INSTALL BASH CONFIG =====
print_info "Installing Bash configuration..."

# Link .bashrc
ln -sf "$DOTFILES_DIR/bash/.bashrc" "$HOME/.bashrc"
print_success "Linked .bashrc"

# ===== INSTALL GIT CONFIG =====
print_info "Installing Git configuration..."

# Link .gitconfig
ln -sf "$DOTFILES_DIR/git/.gitconfig" "$HOME/.gitconfig"
print_success "Linked .gitconfig"

# ===== INSTALL FISH CONFIG =====
print_info "Installing Fish configuration..."

# Create fish config directory
mkdir -p "$HOME/.config/fish"

# Link config.fish
ln -sf "$DOTFILES_DIR/fish/config.fish" "$HOME/.config/fish/config.fish"
print_success "Linked fish config.fish"

# ===== INSTALL TMUX CONFIG =====
print_info "Installing Tmux configuration..."

# Link .tmux.conf
ln -sf "$DOTFILES_DIR/tmux/.tmux.conf" "$HOME/.tmux.conf"
print_success "Linked .tmux.conf"

# ===== INSTALL STARSHIP CONFIG =====
print_info "Installing Starship configuration..."

# Create starship config directory
mkdir -p "$HOME/.config"

# Link starship.toml
ln -sf "$DOTFILES_DIR/starship/starship.toml" "$HOME/.config/starship.toml"
print_success "Linked starship.toml"

# ===== INSTALL YAZI CONFIG =====
print_info "Installing Yazi configuration..."

# Create yazi config directory
mkdir -p "$HOME/.config/yazi"

# Link yazi.toml
ln -sf "$DOTFILES_DIR/yazi/yazi.toml" "$HOME/.config/yazi/yazi.toml"
print_success "Linked yazi.toml"

# ===== CREATE BIN DIRECTORY =====
print_info "Creating bin directory..."

mkdir -p "$HOME/bin"
ln -sf "$DOTFILES_DIR/bin/"* "$HOME/bin/" 2>/dev/null || true
print_success "Linked bin files"

# ===== SET PERMISSIONS =====
print_info "Setting permissions..."

chmod +x "$DOTFILES_DIR/install.sh" 2>/dev/null || true

# ===== INSTALL TOOLS =====
print_info "Checking for required tools..."

install_tool() {
    if ! command -v "$1" &>/dev/null; then
        print_warning "$1 not found. Please install it."
        return 1
    else
        print_success "$1 is installed"
        return 0
    fi
}

install_tool "zsh"
install_tool "fish"
install_tool "starship"
install_tool "eza"
install_tool "bat"
install_tool "fzf"
install_tool "zoxide"
install_tool "yazi"
install_tool "btop"
install_tool "lazygit"

echo ""
echo "=============================================="
echo "         INSTALLATION COMPLETE!           "
echo "=============================================="
echo ""
echo "What to do next:"
echo "1. Restart your terminal"
echo "2. Run: source ~/.zshrc"
echo "3. Install missing tools"
echo "4. Configure: p10k configure"
echo ""
echo "Backup location: $BACKUP_DIR"
echo ""

# ============================================================================
# END OF INSTALL SCRIPT
# ============================================================================