# ============================================================================
# Bash Configuration - Oh My Bash
# ============================================================================

# ===== ENVIRONMENT =====

# Set default editor
export EDITOR="nvim"
export VISUAL="$EDITOR"

# XDG Base Directory
export XDG_CONFIG_HOME="$HOME/.config"
export XDG_DATA_HOME="$HOME/.local/share"
export XDG_CACHE_HOME="$HOME/.cache"

# Development paths
export PATH="$HOME/.local/bin:$PATH"
export PATH="$HOME/.cargo/bin:$PATH"

# History settings
export HISTSIZE=10000
export HISTFILESIZE=10000
export HISTCONTROL=ignoredups:ignorespace

# ===== ALIASES - File Management =====

alias ls='eza -la --icons --git'
alias ll='eza -l --icons --git'
alias la='eza -la --icons'
alias lt='eza -lTg'
alias tree='eza --tree'

# ===== ALIASES - File Viewing =====

alias cat='bat'
alias less='bat'

# ===== ALIASES - Git =====

alias g='lazygit'
alias gs='git status'
alias ga='git add'
alias gc='git commit'
alias gp='git push'
alias gl='git pull'
alias gd='git diff'
alias gco='git checkout'
alias gb='git branch'

# ===== ALIASES - Docker =====

alias d='docker'
alias dc='docker-compose'
alias dcu='docker-compose up -d'
alias dcd='docker-compose down'

# ===== ALIASES - System =====

alias b='btop'
alias ff='fastfetch'

# ===== ALIASES - Navigation =====

alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'

# ===== ALIASES - Utilities =====

alias v='nvim'
alias n='nvim'
alias cls='clear'

# ===== ALIASES - Shortcuts =====

alias lg='lazygit'
alias ld='lazydocker'
alias y='yazi'
alias yy='yazi .'

# ===== TOOL INITIALIZATIONS =====

# Starship prompt
eval "$(starship init bash)"

# Atuin history
eval "$(atuin init bash)"

# zoxide
eval "$(zoxide init bash)"

# fzf
[ -f ~/.fzf.bash ] && source ~/.fzf.bash

# ============================================================================
# END OF BASH CONFIG
# ============================================================================