# Homelab Stack - Quick Start Guide
**Get running in 2 hours**

## Prerequisites Checklist
- [ ] Ubuntu 22.04+ VM with 4+ cores, 16GB RAM, 100GB storage
- [ ] Static IP configured
- [ ] Domain registered with Cloudflare
- [ ] Cloudflare API token ready
- [ ] SSH access to server

---

## 🚀 Rapid Deployment (Copy-Paste Friendly)

### Step 1: System Setup (5 min)
```bash
# Update system
sudo apt update && sudo apt upgrade -y && sudo apt install -y curl git vim htop

# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER

# Configure firewall
sudo ufw allow 22/tcp && sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
sudo ufw --force enable

# Log out and back in for docker group
exit
```

### Step 2: Install Boilerplates (2 min)
```bash
# Install CLI
curl -fsSL https://raw.githubusercontent.com/christianlempa/boilerplates/main/scripts/install.sh | bash

# Update templates
boilerplates repo update

# Set defaults
boilerplates compose defaults set container_timezone="Asia/Qatar"
boilerplates compose defaults set restart_policy="unless-stopped"
```

### Step 3: Generate Secrets (3 min)
```bash
# Create secrets directory
mkdir -p ~/.homelab/secrets && cd ~/.homelab/secrets

# Generate all passwords at once
{
  echo "AUTHENTIK_SECRET_KEY=$(openssl rand -base64 32)"
  echo "AUTHENTIK_POSTGRES_PASSWORD=$(openssl rand -base64 32)"
  echo "AUTHENTIK_BOOTSTRAP_PASSWORD=$(openssl rand -base64 20)"
  echo "PORTAINER_ADMIN_PASSWORD=$(openssl rand -base64 20)"
  echo "GF_ADMIN_PASSWORD=$(openssl rand -base64 20)"
  echo "POSTGRES_PASSWORD=$(openssl rand -base64 32)"
  echo "REDIS_PASSWORD=$(openssl rand -base64 32)"
  echo "PIHOLE_PASSWORD=$(openssl rand -base64 20)"
} | tee passwords.txt

cat passwords.txt
```

### Step 4: Configure Environment (5 min)
```bash
# Create master .env file
cat > ~/.homelab/global.env << 'ENVEOF'
DOMAIN=example.com
HOST_IP=192.168.1.100
TZ=Asia/Qatar
CF_DNS_API_TOKEN=your_cloudflare_token_here
ACME_EMAIL=admin@example.com
AUTHENTIK_SECRET_KEY=paste_from_passwords
AUTHENTIK_BOOTSTRAP_PASSWORD=paste_from_passwords
AUTHENTIK_BOOTSTRAP_EMAIL=admin@example.com
AUTHENTIK_POSTGRES_PASSWORD=paste_from_passwords
PORTAINER_ADMIN_PASSWORD=paste_from_passwords
GF_SECURITY_ADMIN_PASSWORD=paste_from_passwords
PIHOLE_WEBPASSWORD=paste_from_passwords
POSTGRES_PASSWORD=paste_from_passwords
REDIS_PASSWORD=paste_from_passwords
ENVEOF

# Edit with real values
nano ~/.homelab/global.env
```

### Step 5: Deploy Core Stack (30 min)
```bash
# Create project structure
mkdir -p ~/homelab && cd ~/homelab
docker network create proxy

# Deploy Traefik
boilerplates compose generate traefik traefik
cd traefik && nano docker-compose.yml  # Add CF_DNS_API_TOKEN
docker compose up -d && cd ..

# Deploy Authentik
boilerplates compose generate authentik authentik
cd authentik && nano docker-compose.yml  # Add env vars from global.env
docker compose up -d && cd ..

# Deploy Portainer
boilerplates compose generate portainer portainer
cd portainer && nano docker-compose.yml  # Add Traefik labels + env vars
docker compose up -d && cd ..

# Verify all services
docker ps
```

### Step 6: Deploy Monitoring (20 min)
```bash
cd ~/homelab && mkdir -p monitoring && cd monitoring

# Copy monitoring stack from DEPLOYMENT-GUIDE.md
# (Prometheus + Grafana + Loki + Node Exporter + cAdvisor)
# Use the complete docker-compose.yml provided in the guide

docker compose up -d
```

### Step 7: Deploy Homepage (10 min)
```bash
cd ~/homelab && mkdir -p homepage && cd homepage

# Copy Homepage config from DEPLOYMENT-GUIDE.md
docker compose up -d
```

### Step 8: Configure DNS (15 min)
**In Cloudflare Dashboard:**
1. Add A records:
   - `traefik.example.com` → `YOUR_IP`
   - `auth.example.com` → `YOUR_IP`
   - `portainer.example.com` → `YOUR_IP`
   - `grafana.example.com` → `YOUR_IP`
   - `home.example.com` → `YOUR_IP`

2. Enable "Proxy" (orange cloud) for each

**Wait 2-5 minutes for DNS propagation**

### Step 9: Access Services (10 min)
```bash
# Test access
curl -I https://traefik.example.com
curl -I https://auth.example.com

# Open in browser:
https://auth.example.com       # Login: admin@example.com
https://portainer.example.com  # Setup admin account
https://grafana.example.com    # Login: admin
https://home.example.com       # Dashboard view
```

### Step 10: Security Setup (20 min)
**Configure Authentik Forward Auth:**
1. Log in to Authentik → Admin Interface
2. Create **Proxy Provider**:
   - Name: Traefik Forward Auth
   - Mode: Forward auth (single application)
3. Create **Application**: Homelab Services
4. Configure Traefik middleware (see DEPLOYMENT-GUIDE.md)

**Add to each service's docker-compose.yml:**
```yaml
labels:
  - "traefik.http.routers.SERVICE.middlewares=authentik@file"
```

---

## 📊 Service URLs

| Service | URL | Purpose |
|---------|-----|---------|
| Traefik | https://traefik.yourdomain.com | Reverse proxy dashboard |
| Authentik | https://auth.yourdomain.com | SSO/Authentication |
| Portainer | https://portainer.yourdomain.com | Container management |
| Grafana | https://grafana.yourdomain.com | Monitoring dashboards |
| Homepage | https://home.yourdomain.com | Homelab dashboard |

---

## 🔧 Common Commands

```bash
# View all services
docker ps

# View logs
docker compose logs -f SERVICE_NAME

# Restart service
docker compose restart SERVICE_NAME

# Stop all
docker stop $(docker ps -aq)

# Start all
cd ~/homelab/traefik && docker compose up -d
cd ~/homelab/authentik && docker compose up -d
cd ~/homelab/portainer && docker compose up -d
cd ~/homelab/monitoring && docker compose up -d
cd ~/homelab/homepage && docker compose up -d
```

---

## 🆘 Troubleshooting

**Traefik not getting certificates:**
```bash
docker logs traefik | grep -i cert
# Check Cloudflare token permissions
```

**Service unreachable:**
```bash
docker network inspect proxy
# Ensure service is on 'proxy' network
```

**Authentik errors:**
```bash
docker compose logs authentik-server
# Check AUTHENTIK_SECRET_KEY is set
```

---

## 📦 What's Next?

**Phase 1 Complete - You Now Have:**
- ✅ Reverse proxy with auto SSL
- ✅ SSO authentication
- ✅ Container management UI
- ✅ Full monitoring stack
- ✅ Beautiful dashboard

**Next Steps:**
1. Add Pi-hole for network-wide ad blocking
2. Set up automated backups (Duplicati)
3. Configure Grafana dashboards
4. Add more services (media, automation, etc.)
5. Implement backup strategy

**For Full Documentation:**
- See `homelab-stack-architecture.md` for architecture decisions
- See `DEPLOYMENT-GUIDE.md` for detailed step-by-step
- See `environment-template.env` for all variables

---

## 🎯 Success Criteria

- [ ] All services accessible via HTTPS
- [ ] Grafana showing metrics
- [ ] Authentik protecting services
- [ ] Homepage displaying all tiles
- [ ] No certificate errors

---

**Deployment Time:** ~2 hours  
**Difficulty:** Intermediate  
**Stack Value:** Production-ready homelab foundation

---

*Reference Repo:* https://github.com/ChristianLempa/boilerplates
