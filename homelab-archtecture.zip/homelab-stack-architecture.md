# Homelab Infrastructure Stack - Architecture & Deployment Guide

## Executive Summary
This guide provides a production-ready, end-to-end homelab stack built on ChristianLempa's battle-tested boilerplates. The architecture prioritizes security, observability, and developer experience.

---

## 🎯 Infrastructure Segments & Tool Rankings

### 1. **Reverse Proxy / Ingress Layer**
**Winner: Traefik v3**
- Auto SSL (Let's Encrypt/Cloudflare)
- Docker/Swarm native labels
- Dynamic config reload
- Built-in dashboard

**Alternatives:**
- NGINX Proxy Manager (easier GUI)
- Caddy (simpler config)

---

### 2. **Authentication & SSO**
**Winner: Authentik**
- OAuth2/SAML/LDAP support
- Forward auth for Traefik
- User/group management
- TOTP/WebAuthn 2FA

**Alternatives:**
- Authelia
- Keycloak (heavier)

---

### 3. **Container Management**
**Winner: Portainer CE**
- Multi-node orchestration
- Stack/service templates
- RBAC
- Resource monitoring

**Alternatives:**
- Dockge (lightweight)
- Docker Swarm visualizer

---

### 4. **Monitoring & Observability**
**Winner: Grafana + Prometheus + Loki**
- Metrics (Prometheus)
- Logs (Loki)
- Dashboards (Grafana)
- Alert manager integration

**Supporting:**
- Alloy (OpenTelemetry collector)
- Node Exporter
- cAdvisor

**Alternatives:**
- Uptime Kuma (simpler uptime)
- Netdata (all-in-one)

---

### 5. **Dashboard / Homepage**
**Winner: Homepage**
- Service discovery
- Widget integrations
- Traefik labels support
- Beautiful UI

**Alternatives:**
- Dashy
- Homer
- Heimdall

---

### 6. **DNS Management**
**Winner: Pi-hole + Unbound**
- Network-wide ad blocking
- Custom DNS records
- DHCP server
- Recursive resolver (Unbound)

**Alternatives:**
- AdGuard Home
- Technitium DNS

---

### 7. **Automation & Infrastructure as Code**
**Winner: Ansible Semaphore**
- Web UI for Ansible
- Scheduled playbooks
- GitOps workflow
- Audit logs

**Alternatives:**
- AWX
- Terraform + Terraform Cloud

---

### 8. **Backup & Storage**
**Winner: Duplicati**
- Encrypted backups
- Multiple backends (S3, FTP, local)
- Scheduling
- Web UI

**Alternatives:**
- Restic
- Kopia

---

### 9. **Media Services** (Optional)
- Jellyfin (media server)
- qBittorrent
- Sonarr/Radarr/Prowlarr

---

### 10. **Database Layer**
- PostgreSQL (general purpose)
- MySQL/MariaDB (compatibility)
- Redis (caching)

---

## 🏗️ Winning Stack Configuration

### **Core Services (Priority 1)**
```yaml
1. Traefik           # Reverse proxy
2. Authentik         # SSO/Auth
3. Portainer         # Container mgmt
4. Grafana Stack     # Monitoring
5. Homepage          # Dashboard
```

### **Infrastructure Services (Priority 2)**
```yaml
6. Pi-hole + Unbound # DNS
7. Semaphore         # Automation
8. Duplicati         # Backups
9. PostgreSQL        # Database
10. Redis            # Cache
```

---

## 📦 Deployment Strategy

### **Recommended: Single VM with Docker Compose**

**Why?**
- Simplicity: All services in one network namespace
- Resource efficiency: No hypervisor overhead for each service
- Easy backups: Single VM snapshot
- Shared networks: Direct container-to-container comms
- Template compatibility: Boilerplates are Docker Compose native

**Hardware Requirements:**
- **CPU:** 4+ cores (8 preferred)
- **RAM:** 16GB minimum (32GB comfortable)
- **Storage:** 100GB+ SSD
- **Network:** Static IP, port forwarding (80/443)

---

### **Alternative: Proxmox LXC Container**

**Pros:**
- Lower overhead than VM
- Direct hardware access
- Faster startup

**Cons:**
- Nested containerization complexity
- Privileged mode required for Docker
- Less isolation

**LXC Configuration:**
```bash
# Create privileged LXC
pct create 100 local:vztmpl/debian-12-standard_12.2-1_amd64.tar.zst \
  --hostname homelab-stack \
  --cores 4 \
  --memory 8192 \
  --swap 2048 \
  --storage local-lvm \
  --rootfs local-lvm:100 \
  --net0 name=eth0,bridge=vmbr0,ip=dhcp \
  --features nesting=1,keyctl=1 \
  --unprivileged 0

# Enable Docker in LXC
echo "lxc.apparmor.profile: unconfined" >> /etc/pve/lxc/100.conf
echo "lxc.cap.drop:" >> /etc/pve/lxc/100.conf
```

---

### **Alternative: Multi-Node Proxmox VMs**

**Use Case:** Geographic redundancy, resource isolation

**Topology:**
- **VM1:** Traefik + Authentik (edge)
- **VM2:** Core services (Portainer, Grafana)
- **VM3:** Automation + backups

**Complexity:** Requires shared networks (WireGuard/VPN mesh)

---

## 🚀 Deployment Plan

### **Phase 1: Foundation**
```bash
# 1. Install boilerplates CLI
curl -fsSL https://raw.githubusercontent.com/christianlempa/boilerplates/main/scripts/install.sh | bash

# 2. Update templates
boilerplates repo update

# 3. Set global defaults
boilerplates compose defaults set container_timezone="Asia/Qatar"
boilerplates compose defaults set restart_policy="unless-stopped"
```

### **Phase 2: Core Services**

```bash
# Create project directory
mkdir -p ~/homelab/{traefik,authentik,portainer,monitoring,homepage}
cd ~/homelab

# 1. Deploy Traefik (reverse proxy)
boilerplates compose generate traefik traefik \
  --var traefik_enabled=true \
  --var traefik_network=proxy \
  --var cloudflare_api_token=YOUR_CF_TOKEN \
  --no-interactive

# 2. Deploy Authentik (SSO)
boilerplates compose generate authentik authentik \
  --var traefik_enabled=true \
  --var traefik_network=proxy \
  --var traefik_host=auth.yourdomain.com \
  --no-interactive

# 3. Deploy Portainer (container management)
boilerplates compose generate portainer portainer \
  --var traefik_enabled=true \
  --var traefik_network=proxy \
  --var traefik_host=portainer.yourdomain.com \
  --no-interactive

# 4. Deploy Grafana Stack (monitoring)
# Note: May need custom integration
boilerplates compose generate grafana monitoring/grafana \
  --var traefik_enabled=true \
  --no-interactive

# 5. Deploy Homepage (dashboard)
boilerplates compose generate homepage homepage \
  --var traefik_enabled=true \
  --var traefik_host=home.yourdomain.com \
  --no-interactive
```

### **Phase 3: Infrastructure Services**

```bash
# 6. Pi-hole + Unbound
boilerplates compose generate pihole pihole

# 7. Ansible Semaphore
boilerplates compose generate ansiblesemaphore automation/semaphore

# 8. Databases
boilerplates compose generate postgres databases/postgres
boilerplates compose generate redis databases/redis
```

---

## 🔧 Critical Environment Variables to Gather

### **Global Variables**
```bash
# Domain & Networking
DOMAIN=yourdomain.com
TRAEFIK_NETWORK=proxy
HOST_IP=192.168.1.100

# Cloudflare (for SSL)
CF_API_TOKEN=your_cloudflare_api_token
CF_DNS_API_TOKEN=your_cf_dns_token  # If using DNS challenge
CF_ZONE_API_TOKEN=your_zone_token

# Timezone
TZ=Asia/Qatar
```

### **Traefik Specific**
```bash
TRAEFIK_VERSION=v3.5.3
TRAEFIK_DASHBOARD_ENABLED=true
ACME_EMAIL=admin@yourdomain.com
CERT_RESOLVER=cloudflare  # or letsencrypt
```

### **Authentik Specific**
```bash
AUTHENTIK_SECRET_KEY=$(openssl rand -base64 32)
AUTHENTIK_ERROR_REPORTING=false
POSTGRES_PASSWORD=$(openssl rand -base64 32)
POSTGRES_USER=authentik
POSTGRES_DB=authentik
AUTHENTIK_BOOTSTRAP_PASSWORD=YourStrongPassword
AUTHENTIK_BOOTSTRAP_EMAIL=admin@yourdomain.com
```

### **Portainer Specific**
```bash
PORTAINER_ADMIN_PASSWORD=YourStrongPassword
```

### **Grafana Stack**
```bash
GF_SECURITY_ADMIN_PASSWORD=$(openssl rand -base64 32)
GF_SECURITY_ADMIN_USER=admin
GF_SERVER_ROOT_URL=https://grafana.yourdomain.com
PROMETHEUS_RETENTION=15d
LOKI_RETENTION=7d
```

### **Pi-hole**
```bash
PIHOLE_WEBPASSWORD=YourStrongPassword
PIHOLE_DNS1=1.1.1.1
PIHOLE_DNS2=1.0.0.1
```

---

## 📝 Master .env Template

Create `/home/user/.homelab.env`:

```bash
# ============================================
# HOMELAB MASTER ENVIRONMENT VARIABLES
# ============================================

# Domain & Networking
DOMAIN=yourdomain.com
TRAEFIK_NETWORK=proxy
HOST_IP=192.168.1.100
TZ=Asia/Qatar

# Cloudflare
CF_API_TOKEN=your_cloudflare_api_token
CF_DNS_API_TOKEN=your_cf_dns_token
ACME_EMAIL=admin@yourdomain.com

# Traefik
TRAEFIK_VERSION=v3.5.3
TRAEFIK_DASHBOARD_ENABLED=true
CERT_RESOLVER=cloudflare

# Authentik
AUTHENTIK_SECRET_KEY=CHANGEME_GENERATE_WITH_OPENSSL
AUTHENTIK_BOOTSTRAP_PASSWORD=YourStrongPassword
AUTHENTIK_BOOTSTRAP_EMAIL=admin@yourdomain.com
AUTHENTIK_POSTGRES_PASSWORD=CHANGEME_GENERATE_WITH_OPENSSL
AUTHENTIK_POSTGRES_USER=authentik
AUTHENTIK_POSTGRES_DB=authentik

# Portainer
PORTAINER_ADMIN_PASSWORD=YourStrongPassword

# Grafana Stack
GF_SECURITY_ADMIN_PASSWORD=CHANGEME_GENERATE_WITH_OPENSSL
GF_SECURITY_ADMIN_USER=admin
GF_SERVER_ROOT_URL=https://grafana.yourdomain.com
PROMETHEUS_RETENTION=15d
LOKI_RETENTION=7d

# Pi-hole
PIHOLE_WEBPASSWORD=YourStrongPassword
PIHOLE_DNS1=1.1.1.1
PIHOLE_DNS2=1.0.0.1

# Database Defaults
POSTGRES_PASSWORD=CHANGEME_GENERATE_WITH_OPENSSL
MYSQL_ROOT_PASSWORD=CHANGEME_GENERATE_WITH_OPENSSL
REDIS_PASSWORD=CHANGEME_GENERATE_WITH_OPENSSL
```

---

## 🔐 Security Hardening Checklist

- [ ] Generate unique passwords for each service
- [ ] Enable Authentik forward auth for all services
- [ ] Configure firewall (UFW): Allow only 80/443/22
- [ ] Set up automatic backups (Duplicati)
- [ ] Enable 2FA on Authentik
- [ ] Implement fail2ban for SSH
- [ ] Regular `apt update && apt upgrade`
- [ ] Monitor with Grafana alerts
- [ ] Use strong Cloudflare API tokens (scoped)
- [ ] Regular security audits

---

## 📊 Resource Allocation

### **Expected Resource Usage**
```yaml
Traefik:         ~100MB RAM, 1% CPU
Authentik:       ~500MB RAM, 5% CPU
Portainer:       ~150MB RAM, 2% CPU
Grafana Stack:   ~1GB RAM, 10% CPU
Homepage:        ~50MB RAM, 1% CPU
Pi-hole:         ~200MB RAM, 2% CPU
Databases:       ~500MB RAM, 5% CPU
---
Total Baseline:  ~2.5GB RAM, 26% CPU
```

**Recommendation:** Provision 8-16GB RAM for headroom.

---

## 🎓 Learning Path

1. **Week 1:** Deploy Traefik + Portainer
2. **Week 2:** Add Authentik + configure forward auth
3. **Week 3:** Set up monitoring (Grafana stack)
4. **Week 4:** Add Homepage + Pi-hole
5. **Week 5:** Automate with Semaphore + backups

---

## 📚 Key Documentation Links

- [ChristianLempa Boilerplates](https://github.com/ChristianLempa/boilerplates)
- [Traefik Docs](https://doc.traefik.io/traefik/)
- [Authentik Docs](https://docs.goauthentik.io/)
- [Grafana Stack](https://grafana.com/docs/)

---

## 🚨 Troubleshooting Commands

```bash
# Check all services
docker ps -a

# View logs
docker compose logs -f service_name

# Restart stack
docker compose down && docker compose up -d

# Check Traefik routes
docker exec traefik cat /etc/traefik/traefik.yml

# Test DNS resolution
dig @192.168.1.100 yourdomain.com
```

---

## Next Steps

1. Review this architecture
2. Gather environment variables
3. Provision your VM/LXC
4. Execute Phase 1-3 deployment
5. Configure Authentik forward auth
6. Set up monitoring dashboards

**Estimated Setup Time:** 4-8 hours for full stack

---

*Last Updated: January 2026*
*Based on: ChristianLempa Boilerplates v0.1.3*
