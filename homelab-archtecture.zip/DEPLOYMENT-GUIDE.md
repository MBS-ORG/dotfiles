# Homelab Infrastructure Deployment Guide
## Step-by-Step Commands & Configuration

---

## 📋 Prerequisites

### System Requirements
- **OS:** Ubuntu 22.04/24.04 or Debian 12
- **CPU:** 4+ cores
- **RAM:** 16GB minimum
- **Storage:** 100GB+ SSD
- **Network:** Static IP, domain with Cloudflare

---

## 🚀 PHASE 0: System Preparation

### Step 1: Initial System Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install essential tools
sudo apt install -y \
  curl \
  wget \
  git \
  vim \
  htop \
  net-tools \
  ufw \
  ca-certificates \
  gnupg \
  lsb-release

# Set timezone
sudo timedatectl set-timezone Asia/Qatar

# Configure firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable
```

### Step 2: Install Docker

```bash
# Add Docker's official GPG key
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Add Docker repository
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Add user to docker group
sudo usermod -aG docker $USER

# Verify installation
docker --version
docker compose version

# IMPORTANT: Log out and back in for group changes to take effect
```

### Step 3: Install Boilerplates CLI

```bash
# Install via automated script
curl -fsSL https://raw.githubusercontent.com/christianlempa/boilerplates/main/scripts/install.sh | bash

# Verify installation
boilerplates --version

# Update repository library
boilerplates repo update

# List available templates
boilerplates compose list
```

---

## 🔐 PHASE 1: Environment Variables Setup

### Step 1: Generate Secure Passwords

```bash
# Create directory for secrets
mkdir -p ~/.homelab/secrets

# Generate passwords
echo "AUTHENTIK_SECRET_KEY=$(openssl rand -base64 32)" >> ~/.homelab/secrets/passwords.txt
echo "AUTHENTIK_POSTGRES_PASSWORD=$(openssl rand -base64 32)" >> ~/.homelab/secrets/passwords.txt
echo "PORTAINER_ADMIN_PASSWORD=$(openssl rand -base64 20)" >> ~/.homelab/secrets/passwords.txt
echo "GF_SECURITY_ADMIN_PASSWORD=$(openssl rand -base64 20)" >> ~/.homelab/secrets/passwords.txt
echo "POSTGRES_PASSWORD=$(openssl rand -base64 32)" >> ~/.homelab/secrets/passwords.txt
echo "REDIS_PASSWORD=$(openssl rand -base64 32)" >> ~/.homelab/secrets/passwords.txt
echo "PIHOLE_WEBPASSWORD=$(openssl rand -base64 20)" >> ~/.homelab/secrets/passwords.txt

# View generated passwords
cat ~/.homelab/secrets/passwords.txt
```

### Step 2: Cloudflare API Token Setup

**Get Cloudflare API Token:**
1. Log in to Cloudflare Dashboard
2. Go to **Profile → API Tokens**
3. Create token with permissions:
   - `Zone.Zone (Read)`
   - `Zone.DNS (Edit)`
4. Copy the token

### Step 3: Create Master Environment File

```bash
# Create global environment file
cat > ~/.homelab/global.env << 'EOF'
# ============================================
# HOMELAB MASTER CONFIGURATION
# ============================================

# Domain & Network
DOMAIN=yourdomain.com
TRAEFIK_NETWORK=proxy
HOST_IP=192.168.1.100
TZ=Asia/Qatar

# Cloudflare (REPLACE WITH YOUR VALUES)
CF_API_TOKEN=your_cloudflare_api_token_here
CF_DNS_API_TOKEN=your_cloudflare_dns_token_here
ACME_EMAIL=admin@yourdomain.com

# Traefik
TRAEFIK_VERSION=v3.5.3
CERT_RESOLVER=cloudflare

# Authentik (REPLACE WITH GENERATED VALUES)
AUTHENTIK_SECRET_KEY=paste_from_passwords_txt
AUTHENTIK_BOOTSTRAP_PASSWORD=YourStrongPassword
AUTHENTIK_BOOTSTRAP_EMAIL=admin@yourdomain.com
AUTHENTIK_POSTGRES_PASSWORD=paste_from_passwords_txt
AUTHENTIK_POSTGRES_USER=authentik
AUTHENTIK_POSTGRES_DB=authentik

# Portainer
PORTAINER_ADMIN_PASSWORD=paste_from_passwords_txt

# Grafana
GF_SECURITY_ADMIN_PASSWORD=paste_from_passwords_txt
GF_SECURITY_ADMIN_USER=admin
GF_SERVER_ROOT_URL=https://grafana.yourdomain.com

# Pi-hole
PIHOLE_WEBPASSWORD=paste_from_passwords_txt
PIHOLE_DNS1=1.1.1.1
PIHOLE_DNS2=1.0.0.1

# Databases
POSTGRES_PASSWORD=paste_from_passwords_txt
REDIS_PASSWORD=paste_from_passwords_txt
EOF

# Edit and populate with real values
nano ~/.homelab/global.env
```

### Step 4: Set Boilerplates Defaults

```bash
# Set global defaults
boilerplates compose defaults set container_timezone="Asia/Qatar"
boilerplates compose defaults set restart_policy="unless-stopped"
boilerplates compose defaults set traefik_network="proxy"

# Verify defaults
boilerplates compose defaults list
```

---

## 🌐 PHASE 2: Core Infrastructure Deployment

### Step 1: Create Project Structure

```bash
# Create homelab directory
mkdir -p ~/homelab/{traefik,authentik,portainer,monitoring,homepage,pihole,databases}
cd ~/homelab

# Create shared Docker network
docker network create proxy
```

### Step 2: Deploy Traefik (Reverse Proxy)

```bash
cd ~/homelab

# Generate Traefik template
boilerplates compose generate traefik traefik

# Navigate to directory
cd traefik

# IMPORTANT: Edit configuration files
# 1. Update docker-compose.yml with your Cloudflare token
nano docker-compose.yml

# Find and replace:
# - CF_DNS_API_TOKEN=your-cloudflare-api-token

# 2. Configure Traefik static config
nano config/traefik.yml

# Verify configuration syntax
docker compose config

# Deploy Traefik
docker compose up -d

# Check logs
docker compose logs -f

# Verify Traefik is running
docker ps | grep traefik

# Test dashboard (if enabled)
# https://traefik.yourdomain.com
```

**Traefik Configuration Checklist:**
```bash
# In config/traefik.yml, ensure:
- Cloudflare DNS challenge configured
- Certificate resolver defined
- Entrypoints (80, 443) configured
- Dashboard enabled (optional, secure it!)
```

### Step 3: Deploy Authentik (SSO/Auth)

```bash
cd ~/homelab

# Generate Authentik template
boilerplates compose generate authentik authentik

cd authentik

# Load global environment
source ~/.homelab/global.env

# Update docker-compose.yml with environment variables
nano docker-compose.yml

# Update these values:
# - AUTHENTIK_SECRET_KEY
# - AUTHENTIK_BOOTSTRAP_PASSWORD
# - AUTHENTIK_BOOTSTRAP_EMAIL
# - POSTGRES_PASSWORD

# Deploy Authentik stack
docker compose up -d

# Wait for initialization (check logs)
docker compose logs -f authentik-server

# Access Authentik
# https://auth.yourdomain.com
# Login: admin@yourdomain.com
# Password: Your AUTHENTIK_BOOTSTRAP_PASSWORD
```

**Authentik Initial Configuration:**
```bash
# 1. Log in to Authentik web UI
# 2. Navigate to Admin Interface
# 3. Create Application for each service
# 4. Configure Proxy Provider for Traefik forward auth
# 5. Set up groups (admin, users)
```

### Step 4: Deploy Portainer (Container Management)

```bash
cd ~/homelab

# Generate Portainer template
boilerplates compose generate portainer portainer

cd portainer

# Update docker-compose.yml
nano docker-compose.yml

# Add Traefik labels for routing
# Example:
#   labels:
#     - "traefik.enable=true"
#     - "traefik.http.routers.portainer.rule=Host(`portainer.yourdomain.com`)"
#     - "traefik.http.routers.portainer.entrypoints=websecure"
#     - "traefik.http.routers.portainer.tls.certresolver=cloudflare"
#     - "traefik.http.services.portainer.loadbalancer.server.port=9000"
#     - "traefik.docker.network=proxy"

# Deploy Portainer
docker compose up -d

# Check logs
docker compose logs -f

# Access Portainer
# https://portainer.yourdomain.com
```

### Step 5: Deploy Monitoring Stack (Grafana + Prometheus + Loki)

**Option A: Manual Configuration (Recommended)**

```bash
cd ~/homelab/monitoring

# Create directory structure
mkdir -p {grafana,prometheus,loki,promtail}/config
mkdir -p {grafana,prometheus,loki}/data

# Create Prometheus config
cat > prometheus/config/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
EOF

# Create Loki config
cat > loki/config/loki.yml << 'EOF'
auth_enabled: false

server:
  http_listen_port: 3100

ingester:
  lifecycler:
    address: 127.0.0.1
    ring:
      kvstore:
        store: inmemory
      replication_factor: 1
  chunk_idle_period: 5m
  chunk_retain_period: 30s

schema_config:
  configs:
    - from: 2020-05-15
      store: boltdb
      object_store: filesystem
      schema: v11
      index:
        prefix: index_
        period: 168h

storage_config:
  boltdb:
    directory: /loki/index
  filesystem:
    directory: /loki/chunks

limits_config:
  enforce_metric_name: false
  reject_old_samples: true
  reject_old_samples_max_age: 168h
EOF

# Create docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

networks:
  monitoring:
    name: monitoring
  proxy:
    external: true

volumes:
  grafana-data:
  prometheus-data:
  loki-data:

services:
  grafana:
    image: grafana/grafana:latest
    container_name: grafana
    volumes:
      - grafana-data:/var/lib/grafana
    environment:
      - GF_SECURITY_ADMIN_USER=admin
      - GF_SECURITY_ADMIN_PASSWORD=${GF_SECURITY_ADMIN_PASSWORD}
      - GF_SERVER_ROOT_URL=https://grafana.yourdomain.com
      - GF_INSTALL_PLUGINS=grafana-clock-panel,grafana-simple-json-datasource
    networks:
      - monitoring
      - proxy
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.grafana.rule=Host(`grafana.yourdomain.com`)"
      - "traefik.http.routers.grafana.entrypoints=websecure"
      - "traefik.http.routers.grafana.tls.certresolver=cloudflare"
      - "traefik.http.services.grafana.loadbalancer.server.port=3000"
      - "traefik.docker.network=proxy"
    restart: unless-stopped

  prometheus:
    image: prom/prometheus:latest
    container_name: prometheus
    volumes:
      - ./prometheus/config:/etc/prometheus
      - prometheus-data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--storage.tsdb.retention.time=15d'
    networks:
      - monitoring
    restart: unless-stopped

  loki:
    image: grafana/loki:latest
    container_name: loki
    volumes:
      - ./loki/config:/etc/loki
      - loki-data:/loki
    command: -config.file=/etc/loki/loki.yml
    networks:
      - monitoring
    restart: unless-stopped

  node-exporter:
    image: prom/node-exporter:latest
    container_name: node-exporter
    command:
      - '--path.procfs=/host/proc'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)'
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    networks:
      - monitoring
    restart: unless-stopped

  cadvisor:
    image: gcr.io/cadvisor/cadvisor:latest
    container_name: cadvisor
    volumes:
      - /:/rootfs:ro
      - /var/run:/var/run:rw
      - /sys:/sys:ro
      - /var/lib/docker/:/var/lib/docker:ro
    networks:
      - monitoring
    restart: unless-stopped
EOF

# Source environment
source ~/.homelab/global.env

# Deploy monitoring stack
docker compose up -d

# Check all services
docker compose ps

# Access Grafana
# https://grafana.yourdomain.com
# Login: admin / your_password
```

**Configure Grafana Data Sources:**
```bash
# After accessing Grafana UI:
# 1. Add Prometheus data source: http://prometheus:9090
# 2. Add Loki data source: http://loki:3100
# 3. Import dashboard IDs:
#    - 1860 (Node Exporter Full)
#    - 893 (Docker & System Monitoring)
#    - 11074 (Node Exporter for Prometheus)
```

### Step 6: Deploy Homepage (Dashboard)

```bash
cd ~/homelab

# Generate Homepage template (if available)
# Otherwise, manual setup:

mkdir -p homepage/config
cd homepage

# Create docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

networks:
  proxy:
    external: true

services:
  homepage:
    image: ghcr.io/gethomepage/homepage:latest
    container_name: homepage
    volumes:
      - ./config:/app/config
      - /var/run/docker.sock:/var/run/docker.sock:ro
    environment:
      - TZ=Asia/Qatar
    networks:
      - proxy
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.homepage.rule=Host(`home.yourdomain.com`)"
      - "traefik.http.routers.homepage.entrypoints=websecure"
      - "traefik.http.routers.homepage.tls.certresolver=cloudflare"
      - "traefik.http.services.homepage.loadbalancer.server.port=3000"
      - "traefik.docker.network=proxy"
    restart: unless-stopped
EOF

# Create basic config
cat > config/services.yaml << 'EOF'
- Infrastructure:
    - Traefik:
        icon: traefik.png
        href: https://traefik.yourdomain.com
        description: Reverse Proxy

    - Authentik:
        icon: authentik.png
        href: https://auth.yourdomain.com
        description: SSO & Identity

    - Portainer:
        icon: portainer.png
        href: https://portainer.yourdomain.com
        description: Container Management

    - Grafana:
        icon: grafana.png
        href: https://grafana.yourdomain.com
        description: Monitoring & Dashboards
EOF

# Deploy Homepage
docker compose up -d

# Access
# https://home.yourdomain.com
```

---

## 🔧 PHASE 3: Supporting Services

### Step 1: Deploy Pi-hole + Unbound

```bash
cd ~/homelab

# Generate Pi-hole template
boilerplates compose generate pihole pihole

cd pihole

# Update configuration
source ~/.homelab/global.env

nano docker-compose.yml

# Add:
# - WEBPASSWORD=${PIHOLE_WEBPASSWORD}
# - TZ=Asia/Qatar

# Deploy
docker compose up -d

# Access Pi-hole
# http://YOUR_HOST_IP/admin
```

### Step 2: Deploy Databases (PostgreSQL + Redis)

```bash
cd ~/homelab/databases

# Create docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

networks:
  database:
    name: database

volumes:
  postgres-data:
  redis-data:

services:
  postgres:
    image: postgres:16-alpine
    container_name: postgres
    volumes:
      - postgres-data:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
      - POSTGRES_USER=postgres
      - POSTGRES_DB=postgres
    networks:
      - database
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    container_name: redis
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis-data:/data
    networks:
      - database
    restart: unless-stopped
EOF

# Source environment
source ~/.homelab/global.env

# Deploy databases
docker compose up -d
```

---

## 🔐 PHASE 4: Security Configuration

### Step 1: Configure Authentik Forward Auth

**In Authentik UI:**
1. Create Proxy Provider:
   - **Name:** Traefik Forward Auth
   - **Authorization Flow:** default-provider-authorization-implicit-consent
   - **Mode:** Forward auth (single application)

2. Create Application:
   - **Name:** Homelab Services
   - **Provider:** Traefik Forward Auth

3. Note the **Outpost URL** for Traefik middleware

**In Traefik:**

```bash
cd ~/homelab/traefik/config

# Create middleware config
cat > middlewares.yml << 'EOF'
http:
  middlewares:
    authentik:
      forwardAuth:
        address: "http://authentik-server:9000/outpost.goauthentik.io/auth/traefik"
        trustForwardHeader: true
        authResponseHeaders:
          - X-authentik-username
          - X-authentik-groups
          - X-authentik-email
          - X-authentik-name
          - X-authentik-uid
          - X-authentik-jwt
EOF

# Apply to services by adding to labels:
# - "traefik.http.routers.SERVICE.middlewares=authentik@file"
```

### Step 2: Configure UFW Firewall Rules

```bash
# Allow only necessary ports
sudo ufw status numbered

# If needed, add:
sudo ufw allow from 192.168.1.0/24 to any port 9443 # Portainer
sudo ufw allow from 192.168.1.0/24 to any port 3000 # Grafana

# Deny all else
sudo ufw default deny incoming
```

### Step 3: Install Fail2Ban for SSH

```bash
sudo apt install -y fail2ban

# Configure
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local

sudo nano /etc/fail2ban/jail.local

# Set:
# bantime = 1h
# findtime = 10m
# maxretry = 5

sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

---

## 📊 PHASE 5: Verification & Testing

### Step 1: Check All Services

```bash
# List all running containers
docker ps

# Expected output: traefik, authentik-server, authentik-worker, postgres, redis, portainer, grafana, prometheus, loki, homepage

# Check resource usage
docker stats

# View all networks
docker network ls
```

### Step 2: Test Each Service URL

```bash
# Create test script
cat > ~/homelab/test-services.sh << 'EOF'
#!/bin/bash

DOMAIN="yourdomain.com"

services=(
  "traefik.$DOMAIN"
  "auth.$DOMAIN"
  "portainer.$DOMAIN"
  "grafana.$DOMAIN"
  "home.$DOMAIN"
)

for service in "${services[@]}"; do
  echo "Testing $service..."
  curl -sSL -o /dev/null -w "Status: %{http_code}\n" "https://$service" || echo "FAILED"
done
EOF

chmod +x ~/homelab/test-services.sh
./test-services.sh
```

### Step 3: Configure Grafana Dashboards

```bash
# Import recommended dashboards:
# 1. Navigate to Grafana UI
# 2. Click "+" → Import
# 3. Enter dashboard IDs:
#    - 1860 (Node Exporter Full)
#    - 893 (Docker & System Monitoring)
#    - 11074 (Node Exporter)
# 4. Select Prometheus data source
# 5. Import
```

---

## 🔄 PHASE 6: Backup & Maintenance

### Step 1: Setup Automated Backups

```bash
# Create backup script
cat > ~/homelab/backup.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/backup/homelab"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup Docker volumes
docker run --rm -v homelab_traefik_certs:/volume -v $BACKUP_DIR:/backup \
  alpine tar -czf /backup/traefik_certs_$TIMESTAMP.tar.gz -C /volume ./

docker run --rm -v homelab_authentik_postgres:/volume -v $BACKUP_DIR:/backup \
  alpine tar -czf /backup/authentik_db_$TIMESTAMP.tar.gz -C /volume ./

# Backup configs
tar -czf $BACKUP_DIR/configs_$TIMESTAMP.tar.gz -C ~/homelab \
  traefik/config \
  authentik/config \
  monitoring/config

# Keep only last 7 days
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed: $TIMESTAMP"
EOF

chmod +x ~/homelab/backup.sh

# Add to crontab
crontab -e

# Add line:
# 0 2 * * * /home/user/homelab/backup.sh >> /var/log/homelab-backup.log 2>&1
```

### Step 2: Create Update Script

```bash
cat > ~/homelab/update.sh << 'EOF'
#!/bin/bash

cd ~/homelab

for dir in traefik authentik portainer monitoring homepage pihole databases; do
  if [ -d "$dir" ]; then
    echo "Updating $dir..."
    cd "$dir"
    docker compose pull
    docker compose up -d
    cd ..
  fi
done

echo "Pruning unused images..."
docker image prune -af

echo "Update completed!"
EOF

chmod +x ~/homelab/update.sh

# Run monthly
# crontab: 0 3 1 * * /home/user/homelab/update.sh
```

---

## 🎯 Quick Reference Commands

### Daily Operations

```bash
# View all services
cd ~/homelab && docker compose ps -a

# View logs
docker compose logs -f SERVICE_NAME

# Restart service
docker compose restart SERVICE_NAME

# Update single service
docker compose pull SERVICE_NAME && docker compose up -d SERVICE_NAME

# Check resource usage
docker stats

# Check disk space
df -h
```

### Troubleshooting

```bash
# Check Traefik logs
docker logs traefik -f

# Check network connectivity
docker network inspect proxy

# Restart entire stack
cd ~/homelab/traefik && docker compose restart

# Check DNS resolution
nslookup yourdomain.com 1.1.1.1

# Test HTTPS cert
openssl s_client -connect yourdomain.com:443 -servername yourdomain.com
```

---

## 📝 Post-Deployment Checklist

- [ ] All services accessible via HTTPS
- [ ] Authentik SSO configured and protecting services
- [ ] Grafana dashboards displaying metrics
- [ ] Homepage showing all services
- [ ] Automatic backups scheduled
- [ ] Firewall rules configured
- [ ] DNS records pointing to your IP
- [ ] Cloudflare proxy enabled (orange cloud)
- [ ] All passwords stored securely
- [ ] Documentation updated with custom settings

---

## 🆘 Common Issues & Solutions

### Issue: Traefik can't obtain SSL certificates

**Solution:**
```bash
# Check Cloudflare token
docker exec traefik env | grep CF_

# Verify DNS propagation
dig yourdomain.com

# Check Traefik logs
docker logs traefik | grep -i cert
```

### Issue: Services can't reach each other

**Solution:**
```bash
# Verify network
docker network inspect proxy
docker network inspect monitoring

# Ensure services are on correct networks in docker-compose.yml
```

### Issue: High memory usage

**Solution:**
```bash
# Check resource usage
docker stats --no-stream

# Reduce retention periods in Prometheus/Loki configs
# Restart resource-heavy services
docker compose restart grafana prometheus
```

---

## 📚 Additional Resources

- [Traefik Forward Auth Guide](https://doc.traefik.io/traefik/middlewares/http/forwardauth/)
- [Authentik Proxy Provider](https://docs.goauthentik.io/docs/providers/proxy/)
- [Grafana Dashboard Library](https://grafana.com/grafana/dashboards/)
- [Docker Compose Reference](https://docs.docker.com/compose/)

---

**Total Estimated Deployment Time:** 4-6 hours

**Difficulty Level:** Intermediate

**Maintenance:** ~30 min/week

---

*Last Updated: January 2026*
