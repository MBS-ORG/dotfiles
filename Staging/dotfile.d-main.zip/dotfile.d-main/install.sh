#!/usr/bin/env bash
# install.sh — VM 200 bootstrap
# Reproduces the full dev environment from scratch on a fresh KDE Neon / Ubuntu VM.
# Run as the target user (mbs), not as root. Uses sudo internally where needed.
# Idempotent — safe to re-run.
set -euo pipefail

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEV_DIR="$HOME/dev"

log() { echo "[bootstrap] $*"; }

# ── 1. System packages ────────────────────────────────────────────────────────
log "Installing system packages..."
sudo apt-get update -qq
sudo apt-get install -y --no-install-recommends \
  git curl wget stow zsh direnv fzf jq make \
  ripgrep unzip build-essential ca-certificates gnupg lsb-release \
  gh

# ── 2. Docker CE ──────────────────────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
  log "Installing Docker..."
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  sudo chmod a+r /etc/apt/keyrings/docker.gpg
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
    https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
    | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  sudo apt-get update -qq
  sudo apt-get install -y docker-ce docker-ce-cli containerd.io \
    docker-buildx-plugin docker-compose-plugin
  sudo usermod -aG docker "$USER"
  log "Docker installed. Re-login for group membership."
else
  log "Docker already installed: $(docker --version)"
fi

# ── 3. NVM + Node.js 24 ───────────────────────────────────────────────────────
if [ ! -d "$HOME/.nvm" ]; then
  log "Installing NVM..."
  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
fi
export NVM_DIR="$HOME/.nvm"
# shellcheck source=/dev/null
[ -s "$NVM_DIR/nvm.sh" ] && source "$NVM_DIR/nvm.sh"
if ! nvm ls 24 &>/dev/null; then
  log "Installing Node.js 24..."
  nvm install 24
  nvm alias default 24
else
  log "Node.js 24 already installed."
fi

# ── 4. DevPod ─────────────────────────────────────────────────────────────────
DEVPOD_BIN="$HOME/.local/bin/devpod"
if ! command -v devpod &>/dev/null; then
  log "Installing DevPod..."
  mkdir -p "$HOME/.local/bin"
  curl -L "https://github.com/loft-sh/devpod/releases/latest/download/devpod-linux-amd64" \
    -o "$DEVPOD_BIN"
  chmod +x "$DEVPOD_BIN"
fi
if ! devpod provider list 2>/dev/null | grep -q "docker"; then
  log "Configuring DevPod Docker provider..."
  devpod provider add docker --default
fi

# ── 5. Stow dotfiles ──────────────────────────────────────────────────────────
log "Stowing dotfiles from $DOTFILES_DIR..."
cd "$DOTFILES_DIR"
for pkg in bash git gh vscode cursor pam agent; do
  stow --restow --target="$HOME" "$pkg" && log "  stowed: $pkg"
done

# ── 6. Clone dev repos ────────────────────────────────────────────────────────
mkdir -p "$DEV_DIR"

clone_if_missing() {
  local repo=$1 dir=$2
  if [ ! -d "$dir/.git" ]; then
    log "Cloning $repo..."
    git clone "$repo" "$dir"
  else
    log "Repo already exists: $dir"
  fi
}

clone_if_missing "https://github.com/Sabir-test/vmbox"   "$DEV_DIR/vmbox"
clone_if_missing "https://github.com/Sabir-test/responio" "$DEV_DIR/responio"
clone_if_missing "https://github.com/MBS-Limited/Devops"  "$DEV_DIR/Devops"

# Create backward-compat symlink for .workspace/
if [ ! -L "$DEV_DIR/.workspace" ]; then
  ln -sfn "$DEV_DIR/vmbox/templates/devcontainer" "$DEV_DIR/.workspace"
fi

# ── 7. Docker network + dev-base image ────────────────────────────────────────
log "Setting up Docker network and base image..."
docker network create dev-network 2>/dev/null || log "dev-network already exists."

if ! docker image inspect dev-base:latest &>/dev/null; then
  log "Building dev-base:latest..."
  docker build -t dev-base:latest "$DEV_DIR/vmbox/templates/devcontainer/"
else
  log "dev-base:latest already built."
fi

log ""
log "Bootstrap complete."
log "If this was a fresh install, log out and back in for Docker group membership."
