# dotfiles

VM 200 dotfiles — managed with [GNU Stow](https://www.gnu.org/software/stow/).

## Quick start (fresh VM)

```bash
git clone https://github.com/Sabir-test/dotfiles ~/dotfiles
bash ~/dotfiles/install.sh
```

That single script installs all packages, stows configs, clones dev repos,
builds the shared Docker base image, and configures DevPod.

## Structure

Each subdirectory is a **Stow package**. Running `stow <package>` from inside
`~/dotfiles/` creates symlinks in `~/` that mirror the package's directory tree.

| Package | What it manages |
|---|---|
| `bash/` | `.bashrc`, `.profile` |
| `git/` | `.gitconfig` |
| `gh/` | `.config/gh/config.yml` (GitHub CLI) |
| `vscode/` | `.config/Code/User/settings.json` |
| `cursor/` | `.config/Cursor/User/settings.json` |
| `pam/` | `.pam_environment` (locale/env) |
| `agent/` | `.agent/AGENT_VM.md` (AI agent VM rules) |

## Managing individual packages

```bash
cd ~/dotfiles

# Stow (create symlinks)
stow bash

# Re-stow (update existing symlinks)
stow --restow bash

# Unstow (remove symlinks)
stow -D bash

# Dry-run (see what would happen)
stow --simulate bash
```

## Adding a new config

1. Create the package directory mirroring the target path:
   ```
   mkdir -p ~/dotfiles/myapp/.config/myapp/
   mv ~/.config/myapp/config ~/dotfiles/myapp/.config/myapp/config
   ```
2. Stow it: `stow myapp`
3. Commit and push.

## What is NOT tracked

- SSH private keys (`~/.ssh/id_*`)
- GitHub auth tokens (`~/.config/gh/hosts.yml`)
- Claude session data (`~/.claude.json`)
- Browser profiles
- NVM / node_modules (installed by `install.sh`)
